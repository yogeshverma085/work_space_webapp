// import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import TopBar from "./components/TopBar";
import NavBar from "./components/NavBar";
import About from "./components/About";
import Policy from "./components/Policy";
import Contact from "./components/Contact";
import HomeScreen from "./screens/HomeScreen";
import CartScreen from "./screens/CartScreen";
import Registe from "./screens/Registe";
import Login from "./screens/Login";

function App() {
  return (
    <BrowserRouter>
      <TopBar />
      <NavBar />

      <Routes>

        <Route path="/" element={<HomeScreen />} exact />
        <Route path="/about" element={<About />} exact />
        <Route path="/contact" element={<Contact />} exact />
        <Route path="/policy" element={<Policy />} exact />
        <Route path="/login" element={<Login />} exact />
        <Route path="/register" element={<Registe />} exact />
        <Route path="/cart" element={<CartScreen />} exact />
        
      
      </Routes>
      
    </BrowserRouter>
  );
}

export default App;
      
     

