import React from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { FaMinusCircle, FaPlusCircle, FaTrash } from "react-icons/fa";
import { addToCart, deleteFromCart } from "../actions/cartAction";
// import Checkout from "../components/Checkout";
import "./cartStyle.css"

const CartScreen = () => {
  const cartState = useSelector((state) => state.cartReducer);
  const cartItems = cartState.cartItems;
  const dispatch = useDispatch();
  const subTotal = cartItems.reduce((x, item) => x + item.price, 0);
  const tax = .18;
  return (
    <>
      <Container className="cart-main">
        <Row>
          <Col md={6}>
            <h2>My Cart</h2>
            <hr></hr>
            <Row>
              {cartItems.map((item) => (
                <>
                  <Col md={8}>
                    <div style={{ display: "flex" }}>
                      <h5 className="pizza-name">
                        {item.name}
                      </h5>&nbsp;
                      <h5 className="pizza-variety">
                        [{item.varient}]
                      </h5>
                    </div>

                    {/* up down button */}

                    <h6 style={{ display: "flex" }}>
                      {/* Quantity :&nbsp; */}

                      <div className="updown-button">
                        &nbsp;
                        <FaMinusCircle
                          className="text-danger"
                          style={{ cursor: "pointer", width: "35px" }}
                          onClick={() => {
                            dispatch(
                              addToCart(item, item.quantity - 1, item.varient)
                            );
                          }}
                        />{" "}
                        &nbsp;&nbsp;
                        <div className="count" >
                          {item.quantity}
                        </div>
                        &nbsp;&nbsp;
                        <FaPlusCircle
                          className="text-success"
                          style={{ cursor: "pointer", width: "35px" }}
                          onClick={() => {
                            dispatch(
                              addToCart(item, item.quantity + 1, item.varient)
                            );
                          }}
                        />&nbsp;
                      </div>


                    </h6>

                    {/* price  */}

                    <h5 style={{ color: "rgb(169, 67, 3)" }}>&#8377; {item.price}</h5>
                  </Col>
                  <Col md={4}>

                    <img
                      alt={item.name}
                      src={item.image}
                      style={{ width: "80px", height: "80px", borderRadius: "50%" }}
                    />




                    <FaTrash
                      className="text-danger"
                      style={{ cursor: "pointer", marginLeft: "20px" }}
                      onClick={() => {
                        dispatch(deleteFromCart(item));
                      }}

                    />

                  </Col>
                  <hr />
                </>
              ))}
            </Row>
          </Col>

          <Col md={1}>
            {""}
          </Col>


          <Col md={5} className="bill-main">
            <h2>Bill Details</h2>
            <hr></hr>


            <Row>
              <Col md={8}>
                <h6>Item Total</h6>
              </Col>
              <Col md={4}>
                <h6>&#8377; {subTotal} /-</h6>
              </Col>
            </Row>
            <Row>
              <Col md={8}>
                <h6>Delivery Fee</h6>
              </Col>
              <Col md={4}>
                <h6 className="text-success">Free</h6>
              </Col>
            </Row>&nbsp;
            <Row>
              <Col md={8}>
                <h6>Taxes and Charges (18% GST Inc.)</h6>
              </Col>
              <Col md={4}>
                <h6>&#8377; {(subTotal * tax).toFixed(2)} </h6>
              </Col>
            </Row>
            <hr />
            <Row>
              <Col md={8}>
                <h5>Sub Total</h5>
              </Col>
              <Col md={4}>
                <h5>&#8377; {(subTotal + subTotal * tax).toFixed(2)}  /-</h5>
              </Col>
            </Row>
            <Button>Order now</Button>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default CartScreen;
