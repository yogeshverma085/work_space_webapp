import React, { useState } from "react";
import { Card, Button, Row, Col, Modal, Image } from "react-bootstrap";
import { useDispatch } from "react-redux";
import { addToCart } from "../actions/cartAction";
// import {BsFillCartPlusFill} from "r eact-icons/Bs";
import "./pizzaStyle.css";

const Pizza = ({ pizza }) => {
  const [varient, setVarient] = useState("small");
  const [quantity, setQuantity] = useState(1);
  const [show, setShow] = useState(false);

  const dispatch = useDispatch();

  const addToCartHandler = () => {
    dispatch(addToCart(pizza, quantity, varient));
  };

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);


  return (
    <>
      <Card className="maincard">
        {/* { border:"none",borderRadius:"13px",alignItems:"center",justifyContent:"center" ,width: "16.8rem", marginTop: "30px", marginLeft:"0px", fontSize:"13px", backgroundColor:"#dc999982"} */}
        <Card.Img
          className="card-img"
          variant="top"
          src={pizza.image}
          // style={{ height: "240px",marginTop:"3px" ,cursor: "pointer",borderTopRightRadius:"13px", borderTopLeftRadius:"13px",}}
          onClick={handleShow}
        />

        <Card.Body style={{ marginLeft: "-20px" }}>
          
            <Card.Title style={{ marginBottom: "0px" , color:" rgb(169, 67, 3)"}}>
              {pizza.name}
            </Card.Title>


          {/* ******Star**** */}

          <div class="d-flex align-items-center " style={{ marginTop: "7px" }}>
            <div class="rating-stars">
              <Image className="star-image" src="images/grey-star.svg" />
              <div class="filled-star"></div>
            </div>
            &nbsp;
            <h6
              style={{
                marginTop: "0px",
                fontWeight: "lighter",
                opacity: "0.6",
              }}
            >
              (4.5 rating)
            </h6>
          </div>

          <Card.Text>
            <Row>
              <Col md={6}>
                <h6 style={{ fontSize: "13px" }}>Varients</h6>
                <select
                  className="card-select"
                  value={varient}
                  onChange={(e) => setVarient(e.target.value)}
                >
                  {pizza.varients.map((varient) => (
                    <option key={varient}>{varient}</option>
                  ))}
                </select>
              </Col>
              <Col md={6}>
                <h6 style={{ fontSize: "13px" }}>Quantity</h6>
                <select
                  className="card-select"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                >
                  {[...Array(10).keys()].map((v, i) => (
                    <option key={i + 1} value={i + 1}>
                      {i + 1}
                    </option>
                  ))}
                </select>
              </Col>
            </Row>
          </Card.Text>

          <div class="d-flex align-items-baseline">
            <h4 class="mr-2" style={{color:"rgb(222, 31, 10)"}}>&#8377; {pizza.prices[0][varient] * quantity}</h4>
            &nbsp;&nbsp;&nbsp;
            {/* <h5 class="text-striked text-muted mr-3 font-weight-regular">$20</h5> */}
            <h6 class="text-success">42% off</h6>
            <Button
              onClick={addToCartHandler}
              className=" card-button"
              // style={{border:"none",height:"30px",fontSize:"13px",width:"100px"}}
            >
              Add to cart
            </Button>
          </div>

          {/* <Row>
            <Col md={4} style={{marginTop:"6px"}}>&#8377;  {pizza.prices[0][varient] * quantity} </Col>
            <Col md={2}>
              &nbsp;&nbsp;&nbsp;
            </Col>
            <Col md={6}>
              
            </Col>
          </Row> */}
        </Card.Body>
      </Card>

      {/* modal */}

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{pizza.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div>
            <Card.Img
              variant="top"
              src={pizza.image}
              style={{ height: "250px" }}
            />
          </div>
          <div>
            <h5>Description :</h5>
            <h6>{pizza.description}</h6>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default Pizza;
